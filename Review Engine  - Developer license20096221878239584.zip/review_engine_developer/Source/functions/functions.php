<?php
/*
 * "functions.php" include 
 */
require_once PATH_FUNCTIONS . DS . 'constant.php';
require_once PATH_FUNCTIONS . DS . 'general_functions.php';
require_once PATH_FUNCTIONS . DS . 'setup.php';
require_once PATH_FUNCTIONS . DS . 'links.php';
require_once PATH_FUNCTIONS . DS . 'hook_functions.php';
require_once PATH_FUNCTIONS . DS . 'post_type.php';
require_once PATH_FUNCTIONS . DS . 'seo.php';